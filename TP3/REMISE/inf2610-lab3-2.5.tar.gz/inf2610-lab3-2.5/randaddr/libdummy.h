/*
 * libdummy.h
 *
 *  Created on: 2013-08-15
 *      Author: francis
 */

#ifndef LIBDUMMY_H_
#define LIBDUMMY_H_

void foo(void);
void bar(void);
void baz(void);

#endif /* LIBDUMMY_H_ */
