/*
 * stack_tp.c
 *
 *  Created on: 2013-09-16
 *      Author: francis
 */

// Auto-generate tracepoint probe code
#define TRACEPOINT_CREATE_PROBES
#include "stack_tp_provider.h"

