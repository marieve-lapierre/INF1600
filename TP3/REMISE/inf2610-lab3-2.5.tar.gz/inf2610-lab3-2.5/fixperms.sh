#!/bin/sh
FILES="configure"

for F in $FILES; do
	chmod +x $F
done
