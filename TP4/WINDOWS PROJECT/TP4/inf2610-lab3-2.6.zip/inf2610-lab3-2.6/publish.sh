#!/bin/sh
VERSION=2.6
git archive HEAD --prefix inf2610-lab4-${VERSION}/ -o inf2610-lab4-${VERSION}.zip
