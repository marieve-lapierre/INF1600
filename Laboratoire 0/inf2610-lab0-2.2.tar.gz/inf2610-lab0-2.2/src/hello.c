/*
 * hello.c
 *
 *  Created on: 2013-05-21
 *      Author: francis
 */

#include <stdio.h>

int main(int argc, char **argv) {
	printf("Salut Monde!\n");
	return 0;
}
